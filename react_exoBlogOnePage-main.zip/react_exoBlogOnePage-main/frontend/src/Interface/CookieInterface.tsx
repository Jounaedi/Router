export interface CookieInterface {
    hetic_token?: string,
    hetic_username?: string,
    [props: string]: string | undefined
}
