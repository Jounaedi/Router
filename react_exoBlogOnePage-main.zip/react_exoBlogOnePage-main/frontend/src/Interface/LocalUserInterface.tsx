export interface LocalUserInterface {
    username: string,
    password: string,
}
