export interface LocalBlogPost {
    title: string,
    content: string
}
