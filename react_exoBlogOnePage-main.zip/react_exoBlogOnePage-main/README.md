# Un petit Blog OnePage React PHP

Backend PHP Docker, donc pour faire tourner tout ça :
````shell
docker-compose up -d &&
cd ./frontend &&
yarn &&
yarn dev
````

Vous pouvez créer vos propres identifiants, mais de base : 
- FrancisHuster : password
- JohnBob : password
